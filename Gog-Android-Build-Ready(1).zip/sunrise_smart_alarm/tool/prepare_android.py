from pathlib import Path
import re, shutil

root = Path(__file__).resolve().parents[1]
android = root / 'android'
manifest = android / 'app/src/main/AndroidManifest.xml'
main_src = root / 'android_snippets/MainActivity.kt'
main_dst = android / 'app/src/main/kotlin/com/example/sunrise_smart_alarm/MainActivity.kt'

if not manifest.exists():
    raise SystemExit('Android project was not generated. Run flutter create --platforms=android --org com.example . first.')
main_dst.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(main_src, main_dst)

text = manifest.read_text(encoding='utf-8')
permissions = [
 'android.permission.POST_NOTIFICATIONS',
 'android.permission.SCHEDULE_EXACT_ALARM',
 'android.permission.USE_EXACT_ALARM',
 'android.permission.USE_FULL_SCREEN_INTENT',
 'android.permission.WAKE_LOCK',
 'android.permission.RECEIVE_BOOT_COMPLETED',
 'android.permission.VIBRATE',
 'android.permission.CAMERA',
 'android.permission.ACTIVITY_RECOGNITION',
 'android.permission.FOREGROUND_SERVICE',
 'android.permission.FOREGROUND_SERVICE_SPECIAL_USE',
 'android.permission.ACCESS_COARSE_LOCATION',
 'android.permission.ACCESS_FINE_LOCATION',
]
for permission in permissions:
    if f'android:name="{permission}"' not in text:
        text = text.replace('<manifest', f'<manifest', 1)
        # Insert permissions immediately before <application> to avoid disturbing the manifest root.
        marker = '    <application'
        if marker in text:
            text = text.replace(marker, f'    <uses-permission android:name="{permission}" />\n{marker}', 1)
        else:
            text = text.replace('<application', f'<uses-permission android:name="{permission}" />\n    <application', 1)

# Allow the alarm activity to appear over the lock screen and turn the display on.
text = re.sub(r'(<activity\b[^>]*android:name="[^"]*MainActivity"[^>]*)(>)',
              lambda m: m.group(1) +
              ('' if 'android:showWhenLocked=' in m.group(1) else ' android:showWhenLocked="true"') +
              ('' if 'android:turnScreenOn=' in m.group(1) else ' android:turnScreenOn="true"') + m.group(2),
              text, count=1, flags=re.S)

components = '''
        <service android:name="dev.fluttercommunity.plus.androidalarmmanager.AlarmService"
            android:permission="android.permission.BIND_JOB_SERVICE" android:exported="false" />
        <receiver android:name="dev.fluttercommunity.plus.androidalarmmanager.AlarmBroadcastReceiver"
            android:exported="false" />
        <receiver android:name="dev.fluttercommunity.plus.androidalarmmanager.RebootBroadcastReceiver"
            android:enabled="true" android:exported="false">
            <intent-filter><action android:name="android.intent.action.BOOT_COMPLETED" /></intent-filter>
        </receiver>
        <service android:name="com.pravera.flutter_foreground_task.service.ForegroundService"
            android:foregroundServiceType="specialUse" android:exported="false">
            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
                android:value="Sleep tracking for the smart alarm" />
        </service>
'''
if 'dev.fluttercommunity.plus.androidalarmmanager.AlarmService' not in text:
    text = text.replace('</application>', components + '    </application>')
manifest.write_text(text, encoding='utf-8')

# Android 12+ notifications plugin requires core library desugaring.
gradle_kts = android / 'app/build.gradle.kts'
gradle_groovy = android / 'app/build.gradle'
gradle = gradle_kts if gradle_kts.exists() else gradle_groovy
if gradle.exists():
    g = gradle.read_text(encoding='utf-8')
    if gradle.suffix == '.kts':
        if 'isCoreLibraryDesugaringEnabled' not in g:
            g = re.sub(r'(compileOptions\s*\{)', r'\1\n        isCoreLibraryDesugaringEnabled = true', g, count=1)
        if 'coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:' not in g:
            g = re.sub(r'(dependencies\s*\{)', r'\1\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")', g, count=1)
    else:
        if 'coreLibraryDesugaringEnabled true' not in g:
            g = re.sub(r'(compileOptions\s*\{)', r'\1\n        coreLibraryDesugaringEnabled true', g, count=1)
        if 'coreLibraryDesugaring ' not in g:
            g = re.sub(r'(dependencies\s*\{)', r'\1\n    coreLibraryDesugaring "com.android.tools:desugar_jdk_libs:2.1.4"', g, count=1)
    gradle.write_text(g, encoding='utf-8')
print('Android manifest, MainActivity, and desugaring configuration prepared.')
