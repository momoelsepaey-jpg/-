import 'dart:math' as m;
import 'dart:ui' show Color;
import 'solar_calculator.dart';

/// أوضاع الإضاءة. كل وضع يُعرَّف بزاويتي بدء/نهاية للشمس تحت/فوق الأفق.
enum SunriseMode { trueDawn, civilDawn, sunrise, gentleSimulation }

class ModeSpec {
  final String label;
  final String description;
  final double startAngle;
  final double endAngle;
  const ModeSpec(this.label, this.description, this.startAngle, this.endAngle);
}

const modeSpecs = <SunriseMode, ModeSpec>{
  SunriseMode.trueDawn: ModeSpec('الفجر الصادق',
      'من الشفق الفلكي (−18°) حتى الشفق المدني (−6°)', -18, -6),
  SunriseMode.civilDawn: ModeSpec('ضوء الفجر المدني',
      'من −6° حتى لحظة الشروق', -6, SolarCalculator.sunriseAngle),
  SunriseMode.sunrise: ModeSpec('الشروق الكامل',
      'من الشروق حتى ارتفاع الشمس 6° (الساعة الذهبية)',
      SolarCalculator.sunriseAngle, 6),
  SunriseMode.gentleSimulation: ModeSpec('محاكاة هادئة',
      'تدرّج يبلغ ذروته عند الشروق ويبدأ قبله بمدة تختارها', 0, 0),
};

class LightWindow {
  final DateTime start;
  final DateTime end;
  const LightWindow(this.start, this.end);
  double progressAt(DateTime t) {
    final total = end.difference(start).inSeconds;
    if (total <= 0) return 1;
    return (t.difference(start).inSeconds / total).clamp(0.0, 1.0);
  }
}

/// نافذة الضوء للوضع المختار في يوم [date] وموقع معيّن.
LightWindow? lightWindowFor(SunriseMode mode, DateTime date, double lat,
    double lng, {int gentleMinutes = 30}) {
  if (mode == SunriseMode.gentleSimulation) {
    final sr = SolarCalculator.sunrise(date, lat, lng);
    if (sr == null) return null;
    return LightWindow(sr.subtract(Duration(minutes: gentleMinutes)), sr);
  }
  final spec = modeSpecs[mode]!;
  final s = SolarCalculator.morningTime(date, lat, lng, spec.startAngle);
  final e = SolarCalculator.morningTime(date, lat, lng, spec.endAngle);
  if (s == null || e == null) return null;
  return LightWindow(s, e);
}

/// منحنى السطوع: الإضاءة الطبيعية تتصاعد أسّياً تقريباً.
double brightnessCurve(double p) => m.pow(p.clamp(0.0, 1.0), 1.8).toDouble();

/// لون الضوء: من أحمر خافت (~1800K) إلى أبيض دافئ (~5500K).
Color lightColor(double p) {
  const stops = <double>[0, .3, .6, .85, 1];
  const cols = <List<int>>[
    [40, 0, 0], [255, 80, 20], [255, 170, 80], [255, 220, 170], [255, 244, 229]
  ];
  p = p.clamp(0.0, 1.0);
  for (var i = 0; i < stops.length - 1; i++) {
    if (p <= stops[i + 1]) {
      final t = (p - stops[i]) / (stops[i + 1] - stops[i]);
      int l(int a, int b) => (a + (b - a) * t).round();
      return Color.fromARGB(255, l(cols[i][0], cols[i + 1][0]),
          l(cols[i][1], cols[i + 1][1]), l(cols[i][2], cols[i + 1][2]));
    }
  }
  return const Color.fromARGB(255, 255, 244, 229);
}
