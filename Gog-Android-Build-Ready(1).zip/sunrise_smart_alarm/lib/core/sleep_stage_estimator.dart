enum SleepStage { awake, light, deep, rem }

/// تقدير مراحل النوم من حركة الجسم (actigraphy).
/// النوم/اليقظة: نافذة موزونة مستوحاة من Cole–Kripke.
/// المراحل: نموذج دورات 90 دقيقة (العميق في أول الليل، والريم في آخره)
/// يُعدَّل بالحركة الفعلية. تقدير تقريبي وليس تخطيط نوم (PSG).
class SleepStageEstimator {
  static const _w = [404, 598, 326, 441, 1408, 508, 350]; // A-4 .. A+2

  static bool asleep(List<double> a, int i) {
    var d = 0.0;
    for (var k = -4; k <= 2; k++) {
      final j = i + k;
      if (j >= 0 && j < a.length) d += _w[k + 4] * a[j];
    }
    return d * 0.00001 < 1;
  }

  static SleepStage classify(List<double> a, int i, int onsetIndex) {
    if (!asleep(a, i)) return SleepStage.awake;
    final since = (i - onsetIndex).clamp(0, 100000);
    final cycle = since ~/ 90;
    final pos = since % 90;
    var recent = 0.0;
    var cnt = 0;
    for (var k = i - 4; k <= i; k++) {
      if (k >= 0 && k < a.length) {
        recent += a[k];
        cnt++;
      }
    }
    recent = cnt == 0 ? 0 : recent / cnt;

    final deepShare = (1 - 0.28 * cycle).clamp(0.0, 1.0);
    final deepZone = pos >= 8 && pos < 42 ? 1.0 : (pos < 8 ? 0.4 : 0.0);
    final deepScore = deepShare * deepZone;
    final remScore = pos >= 62 ? (0.45 + 0.15 * cycle).clamp(0.0, 0.9) : 0.0;

    if (recent > 6) return SleepStage.light;
    if (deepScore >= 0.5 && recent < 2) return SleepStage.deep;
    if (remScore >= 0.5 && recent < 4) return SleepStage.rem;
    return SleepStage.light;
  }

  /// قرب نهاية دورة نوم (انتقال ريم → خفيف).
  static bool nearCycleEnd(int sinceOnsetMin) {
    final pos = sinceOnsetMin % 90;
    return pos >= 78 || pos <= 4;
  }
}
