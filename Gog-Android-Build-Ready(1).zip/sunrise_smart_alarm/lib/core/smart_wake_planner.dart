import 'sleep_stage_estimator.dart';

class WakeDecision {
  final bool wakeNow;
  final double score;
  final String reason;
  const WakeDecision(this.wakeNow, this.score, this.reason);
}

/// اختيار "أفضل مرحلة استيقاظ" = أقل خمول نوم (sleep inertia) وأفضل أثر صحي،
/// وليس الأبكر:
///  - النوم العميق أسوأ توقيت (خمول شديد): درجة 0.
///  - الخفيف/اليقظة العابرة: 1.  الريم: 0.7.
///  - نهاية دورة مكتملة تعطي مكافأة (لا نقطع دورة في منتصفها).
///  - كفاية النوم مقابل هدف المستخدم، وتقدّم ضوء الفجر، يرفعان الدرجة.
///  - لا نوقظ قبل اكتمال ~85% من النوم المطلوب إلا قرب الموعد النهائي.
class SmartWakePlanner {
  final DateTime windowStart;
  final DateTime deadline;
  final Duration targetSleep;
  final double threshold;

  SmartWakePlanner({
    required this.windowStart,
    required this.deadline,
    this.targetSleep = const Duration(hours: 7, minutes: 30),
    this.threshold = 0.78,
  });

  static double phaseScore(SleepStage s) {
    switch (s) {
      case SleepStage.awake:
      case SleepStage.light:
        return 1.0;
      case SleepStage.rem:
        return 0.7;
      case SleepStage.deep:
        return 0.0;
    }
  }

  WakeDecision decide({
    required DateTime now,
    required SleepStage current,
    required SleepStage previous,
    required int minutesAsleep,
    required double lightProgress,
  }) {
    if (!now.isBefore(deadline)) {
      return const WakeDecision(true, 1, 'بلغنا الموعد النهائي');
    }
    if (now.isBefore(windowStart)) {
      return const WakeDecision(false, 0, 'قبل النافذة');
    }
    final phase = phaseScore(current) * 0.6 +
        (previous == SleepStage.deep ? -0.1 : 0.0);
    final suff = (minutesAsleep / targetSleep.inMinutes).clamp(0.0, 1.0);
    final cycleBonus =
        SleepStageEstimator.nearCycleEnd(minutesAsleep) ? 0.1 : 0.0;
    final score =
        (phase + suff * 0.2 + lightProgress * 0.1 + cycleBonus).clamp(0.0, 1.0);
    if (current == SleepStage.deep) {
      return WakeDecision(false, score, 'نوم عميق: ننتظر');
    }
    final nearDeadline = deadline.difference(now).inMinutes <= 5;
    if (suff < 0.85 && !nearDeadline) {
      return WakeDecision(false, score, 'النوم دون الهدف');
    }
    final ok = score >= threshold;
    return WakeDecision(
        ok, score, ok ? 'مرحلة مناسبة للاستيقاظ' : 'ننتظر مرحلة أفضل');
  }
}
