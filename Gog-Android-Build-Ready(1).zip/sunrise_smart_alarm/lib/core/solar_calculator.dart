import 'dart:math' as m;

/// حساب موضع الشمس بخوارزمية "Sunrise equation" (دقة ≈ دقيقة).
class SolarCalculator {
  static double _rad(double d) => d * m.pi / 180;
  static double _deg(double r) => r * 180 / m.pi;

  static const double sunriseAngle = -0.833; // انكسار الغلاف الجوي + نصف قطر القرص

  /// وقت وصول مركز الشمس إلى زاوية [angle] (سالبة = تحت الأفق) صباح [localDate].
  static DateTime? morningTime(
      DateTime localDate, double lat, double lng, double angle) {
    final noonUtc =
        DateTime.utc(localDate.year, localDate.month, localDate.day, 12);
    final jd = noonUtc.millisecondsSinceEpoch / 86400000.0 + 2440587.5;
    final n = (jd - 2451545.0).round();
    final jStar = n - lng / 360.0; // الشرق أبكر
    final mAnom = (357.5291 + 0.98560028 * jStar) % 360;
    final mr = _rad(mAnom);
    final c = 1.9148 * m.sin(mr) + 0.02 * m.sin(2 * mr) + 0.0003 * m.sin(3 * mr);
    final lambda = (mAnom + c + 180 + 102.9372) % 360;
    final lr = _rad(lambda);
    final jTransit =
        2451545.0 + jStar + 0.0053 * m.sin(mr) - 0.0069 * m.sin(2 * lr);
    final sinDec = m.sin(lr) * m.sin(_rad(23.4397));
    final dec = m.asin(sinDec);
    final latR = _rad(lat);
    final cosH =
        (m.sin(_rad(angle)) - m.sin(latR) * sinDec) / (m.cos(latR) * m.cos(dec));
    if (cosH > 1 || cosH < -1) return null; // لا تبلغ الشمس هذه الزاوية
    final h = _deg(m.acos(cosH));
    final jRise = jTransit - h / 360.0;
    final ms = ((jRise - 2440587.5) * 86400000).round();
    return DateTime.fromMillisecondsSinceEpoch(ms, isUtc: true).toLocal();
  }

  static DateTime? sunrise(DateTime d, double lat, double lng) =>
      morningTime(d, lat, lng, sunriseAngle);
}
