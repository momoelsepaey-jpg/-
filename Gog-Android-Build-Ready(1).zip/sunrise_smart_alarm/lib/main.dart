import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:flutter/material.dart';
import 'services/alarm_service.dart';
import 'ui/home_page.dart';
import 'ui/wake_screen.dart';

final navigatorKey = GlobalKey<NavigatorState>();

void openWake() {
  if (WakeScreen.active) return;
  navigatorKey.currentState
      ?.push(MaterialPageRoute(builder: (_) => const WakeScreen()));
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AndroidAlarmManager.initialize();
  final fromAlarm = await AlarmService.init(onWake: openWake);
  runApp(App(startAtWake: fromAlarm));
}

class App extends StatefulWidget {
  final bool startAtWake;
  const App({super.key, required this.startAtWake});
  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  @override
  void initState() {
    super.initState();
    if (widget.startAtWake) {
      WidgetsBinding.instance.addPostFrameCallback((_) => openWake());
    }
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
        navigatorKey: navigatorKey,
        title: 'منبه الشروق الذكي',
        locale: const Locale('ar'),
        builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.orange),
        home: const HomePage(),
      );
}
