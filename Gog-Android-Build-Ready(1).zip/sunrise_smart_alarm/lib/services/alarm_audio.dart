import 'dart:async';
import 'package:audioplayers/audioplayers.dart';
import 'storage.dart';

/// مصدر الصوت حسب اختيار المستخدم.
Source soundSourceFor(AlarmSettings s) {
  if (s.soundType == 1 && s.soundUri.isNotEmpty) return UrlSource(s.soundUri);
  if (s.soundType == 2 && s.soundUri.isNotEmpty) return DeviceFileSource(s.soundUri);
  return AssetSource('sounds/alarm.mp3');
}

/// صوت تنبيه بارتفاع تدريجي + خفض مؤقت للصوت.
/// ضع ملف الصوت في assets/sounds/alarm.mp3
class AlarmAudio {
  final _player = AudioPlayer();
  Timer? _t;
  double _base = 0.05;
  double _factor = 0.35;
  DateTime? _dipUntil;

  bool get dipping =>
      _dipUntil != null && DateTime.now().isBefore(_dipUntil!);
  int get dipSecondsLeft =>
      dipping ? _dipUntil!.difference(DateTime.now()).inSeconds + 1 : 0;

  Future<void> start({int rampSeconds = 120, Source? source}) async {
    await _player.setReleaseMode(ReleaseMode.loop);
    await _player.setVolume(_base);
    await _player.play(source ?? AssetSource('sounds/alarm.mp3'));
    final step = 0.95 / rampSeconds.clamp(5, 3600);
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      _base = (_base + step).clamp(0.0, 1.0);
      _apply();
    });
  }

  void _apply() => _player.setVolume(dipping ? _base * _factor : _base);

  /// يخفض الصوت إلى [factor] من المستوى الحالي مدة [d] ثم يعود تلقائياً.
  void dip(Duration d, {double factor = 0.35}) {
    _factor = factor;
    _dipUntil = DateTime.now().add(d);
    _apply();
  }

  Future<void> stop() async {
    _t?.cancel();
    await _player.stop();
    await _player.dispose();
  }
}
