import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../core/solar_calculator.dart';
import '../core/sunrise_modes.dart';
import 'storage.dart';

const _alarmId = 7001;

/// تُنفَّذ عند حلول الموعد النهائي (حتى لو كان التطبيق مغلقاً):
/// تُظهر إشعار شاشة كاملة يفتح شاشة الشروق فور بدء التنبيه.
@pragma('vm:entry-point')
Future<void> alarmCallback() async {
  final plugin = FlutterLocalNotificationsPlugin();
  await plugin.initialize(const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher')));
  await plugin.show(
    1001,
    'حان وقت الاستيقاظ',
    'شروق الشمس بانتظارك',
    const NotificationDetails(
      android: AndroidNotificationDetails(
        'wake_channel', 'منبه الشروق',
        importance: Importance.max,
        priority: Priority.max,
        fullScreenIntent: true,
        category: AndroidNotificationCategory.alarm,
        ongoing: true,
        autoCancel: false,
      ),
    ),
    payload: 'wake',
  );
}

class WakePlan {
  final DateTime windowStart; // أبكر وقت للاستيقاظ الذكي
  final DateTime target; // الموعد النهائي بعد ربطه بالوضع
  final LightWindow light;
  const WakePlan(this.windowStart, this.target, this.light);
}

class AlarmService {
  static final _plugin = FlutterLocalNotificationsPlugin();

  /// يعيد true إن كان التطبيق قد فُتح من إشعار المنبه.
  static Future<bool> init({required void Function() onWake}) async {
    await _plugin.initialize(
      const InitializationSettings(
          android: AndroidInitializationSettings('@mipmap/ic_launcher')),
      onDidReceiveNotificationResponse: (r) {
        if (r.payload == 'wake') onWake();
      },
    );
    final android = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await android?.requestNotificationsPermission();
    await android?.requestExactAlarmsPermission();
    await android?.requestFullScreenIntentPermission();
    final d = await _plugin.getNotificationAppLaunchDetails();
    return (d?.didNotificationLaunchApp ?? false) &&
        d?.notificationResponse?.payload == 'wake';
  }

  /// يبني خطة الليلة: يربط الوضع المختار بموعد المستخدم.
  static WakePlan? buildPlan(AlarmSettings s, DateTime now) {
    var day = DateTime(now.year, now.month, now.day);
    DateTime deadlineFor(DateTime d) =>
        d.add(Duration(minutes: s.deadlineMinutes));
    var deadline = deadlineFor(day);
    if (!deadline.isAfter(now)) {
      day = day.add(const Duration(days: 1));
      deadline = deadlineFor(day);
    }
    final light = lightWindowFor(s.mode, day, s.lat, s.lng,
        gentleMinutes: s.gentleMinutes);
    if (light == null) return null;
    var target = light.end;
    if (target.isAfter(deadline)) target = deadline;
    if (s.notBeforeMinutes > 0) {
      final nb = day.add(Duration(minutes: s.notBeforeMinutes));
      if (target.isBefore(nb) && nb.isBefore(deadline)) target = nb;
    }
    final start = target.subtract(Duration(minutes: s.smart ? s.windowMinutes : 0));
    return WakePlan(start, target, light);
  }

  static Future<void> schedule(WakePlan p) async {
    await Storage.savePlan(p.light.start, p.light.end);
    await AndroidAlarmManager.oneShotAt(
      p.target, _alarmId, alarmCallback,
      exact: true, wakeup: true, alarmClock: true,
      allowWhileIdle: true, rescheduleOnReboot: true,
    );
  }

  static Future<void> cancel() async {
    await AndroidAlarmManager.cancel(_alarmId);
    await _plugin.cancel(1001);
  }

  static Future<void> snooze(int minutes) async {
    await AndroidAlarmManager.oneShotAt(
      DateTime.now().add(Duration(minutes: minutes)),
      _alarmId, alarmCallback,
      exact: true, wakeup: true, alarmClock: true, allowWhileIdle: true,
    );
  }

  /// تحقق سريع لاستخدام الاختبارات.
  static DateTime? sunriseFor(DateTime d, double lat, double lng) =>
      SolarCalculator.sunrise(d, lat, lng);
}
