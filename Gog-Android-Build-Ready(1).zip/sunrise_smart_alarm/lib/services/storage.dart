import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/sunrise_modes.dart';

class AlarmSettings {
  int deadlineMinutes;
  int notBeforeMinutes; // 0 = معطّل
  SunriseMode mode;
  bool smart;
  int windowMinutes;
  int targetSleepMinutes;
  int gentleMinutes;
  int snoozeMinutes;
  int rampSeconds;
  List<int> captchas; // فهارس CaptchaType (تُنفَّذ بالتسلسل)
  int walkMeters;
  int strideCm;
  bool preventLock; // منع قفل الهاتف أثناء التنبيه
  int soundType; // 0 افتراضي، 1 نغمة نظام، 2 ملف
  String soundUri;
  String soundName;
  double lat;
  double lng;

  AlarmSettings({
    this.deadlineMinutes = 6 * 60,
    this.notBeforeMinutes = 0,
    this.mode = SunriseMode.civilDawn,
    this.smart = true,
    this.windowMinutes = 30,
    this.targetSleepMinutes = 450,
    this.gentleMinutes = 30,
    this.snoozeMinutes = 9,
    this.rampSeconds = 300,
    List<int>? captchas,
    this.walkMeters = 30,
    this.strideCm = 70,
    this.preventLock = true,
    this.soundType = 0,
    this.soundUri = '',
    this.soundName = 'الافتراضية',
    this.lat = 24.4672, // افتراضي حتى يُحدَّد الـGPS (قابل للتعديل)
    this.lng = 39.6111,
  }) : captchas = captchas ?? [0];

  Map<String, dynamic> toJson() => {
        'deadline': deadlineMinutes, 'notBefore': notBeforeMinutes,
        'mode': mode.index, 'smart': smart, 'window': windowMinutes,
        'target': targetSleepMinutes, 'gentle': gentleMinutes,
        'snooze': snoozeMinutes, 'ramp': rampSeconds,
        'captchas': captchas, 'walk': walkMeters, 'stride': strideCm, 'prevent': preventLock,
        'sType': soundType, 'sUri': soundUri, 'sName': soundName, 'lat': lat, 'lng': lng,
      };

  factory AlarmSettings.fromJson(Map<String, dynamic> j) => AlarmSettings(
        deadlineMinutes: j['deadline'] ?? 360,
        notBeforeMinutes: j['notBefore'] ?? 0,
        mode: SunriseMode.values[j['mode'] ?? 1],
        smart: j['smart'] ?? true,
        windowMinutes: j['window'] ?? 30,
        targetSleepMinutes: j['target'] ?? 450,
        gentleMinutes: j['gentle'] ?? 30,
        snoozeMinutes: j['snooze'] ?? 9,
        rampSeconds: j['ramp'] ?? 300,
        captchas: (j['captchas'] as List?)?.cast<int>().toList(),
        walkMeters: j['walk'] ?? 30,
        strideCm: j['stride'] ?? 70,
        preventLock: j['prevent'] ?? true,
        soundType: j['sType'] ?? 0,
        soundUri: j['sUri'] ?? '',
        soundName: j['sName'] ?? 'الافتراضية',
        lat: (j['lat'] ?? 24.4672).toDouble(),
        lng: (j['lng'] ?? 39.6111).toDouble(),
      );
}

class NightRecord {
  final DateTime date;
  final int sleepMinutes;
  final String wakeStage;
  final double score;
  NightRecord(this.date, this.sleepMinutes, this.wakeStage, this.score);
  Map<String, dynamic> toJson() => {
        'd': date.millisecondsSinceEpoch, 'm': sleepMinutes,
        's': wakeStage, 'sc': score
      };
  factory NightRecord.fromJson(Map<String, dynamic> j) => NightRecord(
      DateTime.fromMillisecondsSinceEpoch(j['d']), j['m'], j['s'],
      (j['sc'] as num).toDouble());
}

class Storage {
  static Future<AlarmSettings> loadSettings() async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString('settings');
    return s == null ? AlarmSettings() : AlarmSettings.fromJson(jsonDecode(s));
  }

  static Future<void> saveSettings(AlarmSettings s) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('settings', jsonEncode(s.toJson()));
  }

  static Future<void> savePlan(DateTime start, DateTime end) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('plan_start', start.millisecondsSinceEpoch);
    await p.setInt('plan_end', end.millisecondsSinceEpoch);
  }

  static Future<LightWindow?> loadPlan() async {
    final p = await SharedPreferences.getInstance();
    final a = p.getInt('plan_start'), b = p.getInt('plan_end');
    if (a == null || b == null) return null;
    return LightWindow(DateTime.fromMillisecondsSinceEpoch(a),
        DateTime.fromMillisecondsSinceEpoch(b));
  }

  static Future<List<NightRecord>> history() async {
    final p = await SharedPreferences.getInstance();
    final l = p.getStringList('history') ?? [];
    return l.map((e) => NightRecord.fromJson(jsonDecode(e))).toList();
  }

  static Future<void> addNight(NightRecord r) async {
    final p = await SharedPreferences.getInstance();
    final l = p.getStringList('history') ?? [];
    l.add(jsonEncode(r.toJson()));
    await p.setStringList('history', l.length > 90 ? l.sublist(l.length - 90) : l);
  }

  /// دَين النوم لآخر 7 ليالٍ (بالدقائق) مقابل الهدف.
  static Future<int> sleepDebt(int targetMinutes) async {
    final h = await history();
    final last = h.length > 7 ? h.sublist(h.length - 7) : h;
    var debt = 0;
    for (final n in last) {
      if (n.sleepMinutes < targetMinutes) debt += targetMinutes - n.sleepMinutes;
    }
    return debt;
  }
}
