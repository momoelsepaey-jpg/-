import 'package:flutter/services.dart';

/// جسر إلى Kotlin: منع القفل أثناء التنبيه + اختيار نغمة النظام.
class AlarmMode {
  static const _ch = MethodChannel('sunrise/alarm_mode');

  static Future<void> start({bool prevent = true}) async {
    try {
      await _ch.invokeMethod('start', {'prevent': prevent});
    } catch (_) {}
  }

  static Future<void> stop() async {
    try {
      await _ch.invokeMethod('stop');
    } catch (_) {}
  }

  static Future<Map<String, String>?> pickRingtone() async {
    try {
      final m = await _ch.invokeMethod<Map>('pickRingtone');
      return m?.map((k, v) => MapEntry(k.toString(), v.toString()));
    } catch (_) {
      return null;
    }
  }
}
