import 'dart:async';
import 'dart:math' as m;
import 'package:flutter/material.dart';
import 'package:pedometer/pedometer.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sensors_plus/sensors_plus.dart';
import '../services/storage.dart';
import 'tea_cup_recognizer.dart';

enum CaptchaType { math, walk, teaCup }

const captchaLabels = {
  CaptchaType.math: 'مسألة حسابية',
  CaptchaType.walk: 'المشي مسافة معينة',
  CaptchaType.teaCup: 'تصوير كوب الشاي',
};

/// يشغّل الكابتشا المختارة بالتسلسل، وعند اكتمالها كلها يستدعي [onSuccess].
class CaptchaFlow extends StatefulWidget {
  final AlarmSettings settings;
  final VoidCallback onSuccess;
  const CaptchaFlow({super.key, required this.settings, required this.onSuccess});
  @override
  State<CaptchaFlow> createState() => _CaptchaFlowState();
}

class _CaptchaFlowState extends State<CaptchaFlow> {
  late final List<CaptchaType> _types;
  int _i = 0;

  @override
  void initState() {
    super.initState();
    _types = widget.settings.captchas.map((i) => CaptchaType.values[i]).toList();
    if (_types.isEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) => widget.onSuccess());
    }
  }

  void _next() {
    if (_i + 1 >= _types.length) {
      widget.onSuccess();
    } else {
      setState(() => _i++);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_types.isEmpty) return const SizedBox.shrink();
    final t = _types[_i];
    Widget step;
    switch (t) {
      case CaptchaType.math:
        step = _MathStep(onDone: _next);
        break;
      case CaptchaType.walk:
        step = _WalkStep(
            meters: widget.settings.walkMeters,
            strideCm: widget.settings.strideCm,
            onDone: _next);
        break;
      case CaptchaType.teaCup:
        step = _TeaStep(onDone: _next);
        break;
    }
    return Card(
      color: Colors.black.withOpacity(.55),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: DefaultTextStyle.merge(
          style: const TextStyle(color: Colors.white),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('الخطوة ${_i + 1} من ${_types.length}: ${captchaLabels[t]}'),
            const SizedBox(height: 12),
            KeyedSubtree(key: ValueKey(_i), child: step),
          ]),
        ),
      ),
    );
  }
}

// ---------------- رياضيات ----------------
class _MathStep extends StatefulWidget {
  final VoidCallback onDone;
  const _MathStep({required this.onDone});
  @override
  State<_MathStep> createState() => _MathStepState();
}

class _MathStepState extends State<_MathStep> {
  final _r = m.Random();
  final _c = TextEditingController();
  late int a, b, k;
  String err = '';

  @override
  void initState() {
    super.initState();
    _gen();
  }

  void _gen() {
    a = 12 + _r.nextInt(80);
    b = 3 + _r.nextInt(9);
    k = 10 + _r.nextInt(40);
    _c.clear();
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        Text('$a × $b + $k = ؟', style: const TextStyle(fontSize: 22)),
        TextField(
          controller: _c,
          keyboardType: TextInputType.number,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
              filled: true, fillColor: Colors.white24, hintText: 'الجواب'),
        ),
        if (err.isNotEmpty) Text(err, style: const TextStyle(color: Colors.redAccent)),
        const SizedBox(height: 8),
        FilledButton(
          onPressed: () {
            if (int.tryParse(_c.text.trim()) == a * b + k) {
              widget.onDone();
            } else {
              setState(() {
                err = 'خطأ، مسألة جديدة';
                _gen();
              });
            }
          },
          child: const Text('تأكيد'),
        ),
      ]);
}

// ---------------- المشي ----------------
class _WalkStep extends StatefulWidget {
  final int meters, strideCm;
  final VoidCallback onDone;
  const _WalkStep({required this.meters, required this.strideCm, required this.onDone});
  @override
  State<_WalkStep> createState() => _WalkStepState();
}

class _WalkStepState extends State<_WalkStep> {
  StreamSubscription? _sub;
  int? _base;
  int _steps = 0;
  bool _done = false;
  DateTime _lastPeak = DateTime.now();

  double get _meters => _steps * widget.strideCm / 100.0;

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    await Permission.activityRecognition.request();
    try {
      _sub = Pedometer.stepCountStream.listen(
        (e) {
          _base ??= e.steps;
          _update(e.steps - _base!);
        },
        onError: (_) => _fallback(),
      );
    } catch (_) {
      _fallback();
    }
  }

  /// بديل: عدّ الخطوات من قمم مقياس التسارع لو لم يتوفر مستشعر الخطوات.
  void _fallback() {
    _sub?.cancel();
    _sub = accelerometerEventStream().listen((e) {
      final mag = m.sqrt(e.x * e.x + e.y * e.y + e.z * e.z);
      final now = DateTime.now();
      if (mag > 11.5 && now.difference(_lastPeak).inMilliseconds > 350) {
        _lastPeak = now;
        _update(_steps + 1);
      }
    });
  }

  void _update(int steps) {
    if (_done || !mounted) return;
    setState(() => _steps = steps);
    if (_meters >= widget.meters) {
      _done = true;
      _sub?.cancel();
      widget.onDone();
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        Text('امشِ ${widget.meters} متراً', style: const TextStyle(fontSize: 20)),
        const SizedBox(height: 8),
        LinearProgressIndicator(value: (_meters / widget.meters).clamp(0.0, 1.0)),
        const SizedBox(height: 8),
        Text('${_meters.toStringAsFixed(0)} م  •  $_steps خطوة'),
      ]);
}

// ---------------- كوب الشاي ----------------
class _TeaStep extends StatefulWidget {
  final VoidCallback onDone;
  const _TeaStep({required this.onDone});
  @override
  State<_TeaStep> createState() => _TeaStepState();
}

class _TeaStepState extends State<_TeaStep> {
  bool busy = false;
  String msg = '';

  Future<void> _shoot() async {
    setState(() {
      busy = true;
      msg = '';
    });
    final r = await TeaCupRecognizer.verify();
    if (!mounted) return;
    if (r.ok) {
      widget.onDone();
    } else {
      setState(() {
        busy = false;
        msg = r.message;
      });
    }
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        const Text('اذهب لتحضير الشاي وصوّر كوبك', style: TextStyle(fontSize: 18)),
        if (msg.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(msg, style: const TextStyle(color: Colors.redAccent)),
          ),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: busy ? null : _shoot,
          icon: const Icon(Icons.camera_alt),
          label: Text(busy ? 'جارٍ التحليل…' : 'افتح الكاميرا'),
        ),
      ]);
}
