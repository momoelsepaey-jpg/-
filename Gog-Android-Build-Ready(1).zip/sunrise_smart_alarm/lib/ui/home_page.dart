import 'dart:async';
import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../core/sunrise_modes.dart';
import '../services/alarm_audio.dart';
import '../services/alarm_mode.dart';
import '../services/alarm_service.dart';
import '../services/night_controller.dart';
import '../services/storage.dart';
import '../captcha/captchas.dart';
import '../captcha/tea_cup_recognizer.dart';
import '../main.dart' show openWake;

String _hm(DateTime t) =>
    '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  AlarmSettings s = AlarmSettings();
  late final NightController night = NightController(onWake: openWake);
  String status = '';
  int debt = 0;
  List<NightRecord> hist = [];
  WakePlan? plan;
  int cupRefs = 0;
  StreamSubscription<String>? _st;

  @override
  void initState() {
    super.initState();
    _load();
    _st = night.status.listen((t) => setState(() => status = t));
  }

  Future<void> _load() async {
    s = await Storage.loadSettings();
    hist = await Storage.history();
    debt = await Storage.sleepDebt(s.targetSleepMinutes);
    cupRefs = await TeaCupRecognizer.refCount();
    _refreshPlan();
  }

  void _refreshPlan() {
    plan = AlarmService.buildPlan(s, DateTime.now());
    setState(() {});
  }

  Future<void> _save() async {
    await Storage.saveSettings(s);
    _refreshPlan();
  }

  Future<void> _chooseSound() async {
    final c = await showModalBottomSheet<int>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
              title: const Text('الافتراضية (assets/sounds/alarm.mp3)'),
              onTap: () => Navigator.pop(context, 0)),
          ListTile(
              title: const Text('نغمات المنبه في الجهاز'),
              onTap: () => Navigator.pop(context, 1)),
          ListTile(
              title: const Text('اختيار ملف صوتي'),
              onTap: () => Navigator.pop(context, 2)),
        ]),
      ),
    );
    if (c == null) return;
    if (c == 0) {
      s.soundType = 0;
      s.soundUri = '';
      s.soundName = 'الافتراضية';
    } else if (c == 1) {
      final r = await AlarmMode.pickRingtone();
      if (r == null) return;
      s.soundType = 1;
      s.soundUri = r['uri']!;
      s.soundName = r['name']!;
    } else {
      final f = await FilePicker.platform.pickFiles(type: FileType.audio);
      final path = f?.files.single.path;
      if (path == null) return;
      final dir = await getApplicationDocumentsDirectory();
      final ext = path.contains('.') ? path.substring(path.lastIndexOf('.')) : '.mp3';
      final dst = await File(path).copy('${dir.path}/alarm_custom$ext');
      s.soundType = 2;
      s.soundUri = dst.path;
      s.soundName = path.split('/').last;
    }
    await _save();
  }

  Future<void> _preview() async {
    final p = AudioPlayer();
    try {
      await p.play(soundSourceFor(s));
      await Future.delayed(const Duration(seconds: 6));
    } finally {
      await p.stop();
      await p.dispose();
    }
  }

  Future<void> _gps() async {
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      final p = await Geolocator.getCurrentPosition(
          locationSettings:
              const LocationSettings(accuracy: LocationAccuracy.low));
      s.lat = p.latitude;
      s.lng = p.longitude;
      await _save();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('تعذّر تحديد الموقع')));
      }
    }
  }

  @override
  void dispose() {
    _st?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dl = TimeOfDay(hour: s.deadlineMinutes ~/ 60, minute: s.deadlineMinutes % 60);
    return Scaffold(
      appBar: AppBar(title: const Text('منبه الشروق الذكي')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        ListTile(
          title: const Text('الموعد النهائي'),
          subtitle: Text(dl.format(context)),
          trailing: const Icon(Icons.access_time),
          onTap: () async {
            final t = await showTimePicker(context: context, initialTime: dl);
            if (t != null) {
              s.deadlineMinutes = t.hour * 60 + t.minute;
              _save();
            }
          },
        ),
        const Divider(),
        const Text('وضع الاستيقاظ مع الشمس'),
        for (final md in SunriseMode.values)
          RadioListTile<SunriseMode>(
            value: md,
            groupValue: s.mode,
            title: Text(modeSpecs[md]!.label),
            subtitle: Text(modeSpecs[md]!.description),
            onChanged: (v) {
              s.mode = v!;
              _save();
            },
          ),
        if (s.mode == SunriseMode.gentleSimulation)
          ListTile(
            title: Text('مدة المحاكاة: ${s.gentleMinutes} د'),
            subtitle: Slider(
                min: 10, max: 60, divisions: 10, value: s.gentleMinutes.toDouble(),
                onChanged: (v) { s.gentleMinutes = v.round(); _save(); }),
          ),
        const Divider(),
        SwitchListTile(
          title: const Text('الاستيقاظ الذكي (أفضل مرحلة)'),
          subtitle: const Text('يتجنب النوم العميق، ويفضّل نهاية دورة نوم مكتملة'),
          value: s.smart,
          onChanged: (v) { s.smart = v; _save(); },
        ),
        if (s.smart) ...[
          ListTile(
            title: Text('نافذة الاستيقاظ: ${s.windowMinutes} د قبل الموعد'),
            subtitle: Slider(
                min: 10, max: 60, divisions: 10, value: s.windowMinutes.toDouble(),
                onChanged: (v) { s.windowMinutes = v.round(); _save(); }),
          ),
          ListTile(
            title: Text('هدف النوم: ${(s.targetSleepMinutes / 60).toStringAsFixed(1)} ساعة'),
            subtitle: Slider(
                min: 300, max: 600, divisions: 20, value: s.targetSleepMinutes.toDouble(),
                onChanged: (v) { s.targetSleepMinutes = v.round(); _save(); }),
          ),
        ],
        const Divider(),
        ListTile(
          title: const Text('نغمة المنبه'),
          subtitle: Text(s.soundName),
          trailing: IconButton(icon: const Icon(Icons.play_arrow), onPressed: _preview),
          onTap: _chooseSound,
        ),
        SwitchListTile(
          title: const Text('منع قفل الهاتف أثناء التنبيه'),
          subtitle: const Text('تثبيت الشاشة + إعادة تشغيلها إن ضغطت زر القفل + إعادة التنبيه إن أُغلق التطبيق'),
          value: s.preventLock,
          onChanged: (v) { s.preventLock = v; _save(); },
        ),
        const Divider(),
        const Text('طرق إيقاف المنبه (كابتشا) — تُنفَّذ بالتسلسل'),
        for (final c in CaptchaType.values)
          CheckboxListTile(
            title: Text(captchaLabels[c]!),
            value: s.captchas.contains(c.index),
            onChanged: (v) {
              if (v == true) {
                if (!s.captchas.contains(c.index)) s.captchas.add(c.index);
              } else {
                s.captchas.remove(c.index);
              }
              s.captchas.sort();
              _save();
            },
          ),
        if (s.captchas.contains(CaptchaType.walk.index))
          ListTile(
            title: Text('مسافة المشي: ${s.walkMeters} م'),
            subtitle: Slider(
                min: 10, max: 200, divisions: 19, value: s.walkMeters.toDouble(),
                onChanged: (v) { s.walkMeters = v.round(); _save(); }),
          ),
        if (s.captchas.contains(CaptchaType.teaCup.index))
          ListTile(
            title: Text(cupRefs == 0
                ? 'سجّل كوب الشاي (تصوير مرة واحدة)'
                : 'كوبك مسجَّل ($cupRefs عيّنات) — أعد التصوير للتحسين'),
            trailing: const Icon(Icons.camera_alt),
            onTap: () async {
              final r = await TeaCupRecognizer.enroll();
              cupRefs = await TeaCupRecognizer.refCount();
              if (!mounted) return;
              setState(() {});
              ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text(r.message)));
            },
          ),
        ListTile(
          title: Text('الموقع: ${s.lat.toStringAsFixed(3)}, ${s.lng.toStringAsFixed(3)}'),
          trailing: const Icon(Icons.my_location),
          onTap: _gps,
        ),
        const Divider(),
        if (plan != null)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                'ضوء الوضع: ${_hm(plan!.light.start)} ← ${_hm(plan!.light.end)}\n'
                '${s.smart ? 'نافذة الاستيقاظ الذكي: ${_hm(plan!.windowStart)} ← ' : 'التنبيه: '}${_hm(plan!.target)}',
              ),
            ),
          ),
        if (status.isNotEmpty) Padding(padding: const EdgeInsets.all(8), child: Text(status)),
        const SizedBox(height: 8),
        FilledButton(
          onPressed: night.running
              ? () async { await night.cancelNight(); setState(() {}); }
              : () async { await night.start(s); setState(() {}); },
          child: Text(night.running ? 'إلغاء الليلة' : 'ابدأ النوم'),
        ),
        const SizedBox(height: 16),
        Text('دَين النوم (7 ليالٍ): ${debt ~/ 60} س ${debt % 60} د'),
        for (final n in hist.reversed.take(7))
          ListTile(
            dense: true,
            title: Text('${n.date.day}/${n.date.month} — نوم ${n.sleepMinutes ~/ 60} س ${n.sleepMinutes % 60} د'),
            subtitle: Text('مرحلة الاستيقاظ: ${n.wakeStage} • الدرجة ${(n.score * 100).round()}%'),
          ),
      ]),
    );
  }
}
