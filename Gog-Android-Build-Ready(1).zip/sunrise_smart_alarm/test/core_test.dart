import 'package:flutter_test/flutter_test.dart';
import 'package:sunrise_smart_alarm/captcha/tea_cup_recognizer.dart';
import 'package:sunrise_smart_alarm/core/solar_calculator.dart';
import 'package:sunrise_smart_alarm/core/sleep_stage_estimator.dart';
import 'package:sunrise_smart_alarm/core/smart_wake_planner.dart';

void main() {
  test('ترتيب الفجر قبل الشروق', () {
    final d = DateTime(2026, 11, 22);
    final a = SolarCalculator.morningTime(d, 24.4672, 39.6111, -18)!;
    final c = SolarCalculator.morningTime(d, 24.4672, 39.6111, -6)!;
    final s = SolarCalculator.sunrise(d, 24.4672, 39.6111)!;
    expect(a.isBefore(c), true);
    expect(c.isBefore(s), true);
  });

  test('لا نوقظ من نوم عميق', () {
    final now = DateTime(2026, 11, 22, 5, 30);
    final p = SmartWakePlanner(
        windowStart: DateTime(2026, 11, 22, 5, 0),
        deadline: DateTime(2026, 11, 22, 6, 0));
    final d = p.decide(
        now: now, current: SleepStage.deep, previous: SleepStage.deep,
        minutesAsleep: 480, lightProgress: .5);
    expect(d.wakeNow, false);
    final l = p.decide(
        now: now, current: SleepStage.light, previous: SleepStage.rem,
        minutesAsleep: 480, lightProgress: .5);
    expect(l.wakeNow, true);
  });

  test('تقاطع الهيستوغرام', () {
    final a = List<double>.filled(64, 1 / 64);
    expect(TeaCupRecognizer.intersection(a, a), closeTo(1, 1e-9));
    final b = List<double>.filled(64, 0)..[0] = 1;
    expect(TeaCupRecognizer.intersection(a, b), closeTo(1 / 64, 1e-9));
  });
}
